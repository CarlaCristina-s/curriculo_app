function carregarDados() {
  const petsNaMemoria = JSON.parse(localStorage.getItem("pets"));

  const lista = document.getElementById("lista-pets");

  petsNaMemoria.forEach((pet) => {
    console.log(pet.nome);
    // geração da div
    const div = document.createElement("div");
    div.classList.add("item-pet");

    const img = document.createElement("img");
    img.setAttribute("width", "150px");
    img.setAttribute("height", "150px");
    img.style.objectFit = "cover";
    img.setAttribute("src", pet.foto);
    div.append(img);

    const h2 = document.createElement("h2");
    h2.innerText = pet.nome;
    div.append(h2); // append sempre joga para o final após o último filho

    const button = document.createElement("button");
    button.innerText = "Adotar";
    div.append(button);
    // fim da geração da div

    lista.append(div);
  });
}

document.addEventListener("DOMContentLoaded", carregarDados); // evento para disparar quando o conteúdo for carregado (função)
