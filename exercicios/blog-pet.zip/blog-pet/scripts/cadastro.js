function cadastrarPet(event) {
  event.preventDefault();

  const foto = document.getElementById("foto").value;
  const nome = document.getElementById("nome").value;
  const idade = document.getElementById("idade").value;
  const categoria = document.getElementById("categoria").value;
  const descricao = document.getElementById("descricao").value;
  const responsavel = document.getElementById("responsavel").value;
  const email = document.getElementById("email").value;
  const telefone = document.getElementById("telefone").value;
  const data = document.getElementById("data").value;
  const hora = document.getElementById("hora").value;
  const local = document.getElementById("local").value;


  if(foto === "") {
    document.getElementById('foto').style.borderColor = "red"
    document.getElementById('foto').style.borderWidth = "2px"

    document.getElementById('error-foto').innerText = "Você precisa cadastrar uma foto"
 }

  if(nome === "") {
    document.getElementById('nome').style.borderColor = "red"
    document.getElementById('nome').style.borderWidth = "2px"

    document.getElementById('error-nome').innerText = "Nome é obrigatório"
 }

 if(idade === "") {
  document.getElementById('idade').style.borderColor = "red"
  document.getElementById('idade').style.borderWidth = "2px"

  document.getElementById('error-idade').innerText = "Idade é obrigatório"
}

if(categoria === "") {
  document.getElementById('categoria').style.borderColor = "red"
  document.getElementById('categoria').style.borderWidth = "2px"

  document.getElementById('error-categoria').innerText = "Selecione uma categoria"
}

if(descricao === "") {
  document.getElementById('descricao').style.borderColor = "red"
  document.getElementById('descricao').style.borderWidth = "2px"

  document.getElementById('error-descricao').innerText = "Descrição do pet é obrigatório"
}

if(responsavel === "") {
  document.getElementById('responsavel').style.borderColor = "red"
  document.getElementById('responsavel').style.borderWidth = "2px"

  document.getElementById('error-responsavel').innerText = "Você precisa cadastrar um responsável"
}

if(email === "") {
  document.getElementById('email').style.borderColor = "red"
  document.getElementById('email').style.borderWidth = "2px"

  document.getElementById('error-email').innerText = "E-mail é obrigatório"
}

if(telefone === "") {
  document.getElementById('telefone').style.borderColor = "red"
  document.getElementById('telefone').style.borderWidth = "2px"

  document.getElementById('error-telefone').innerText = "Telefone é obrigatório"
}

if(data === "") {
  document.getElementById('data').style.borderColor = "red"
  document.getElementById('data').style.borderWidth = "2px"

  document.getElementById('error-data').innerText = "Data é obrigatório"
}

if(hora === "") {
  document.getElementById('hora').style.borderColor = "red"
  document.getElementById('hora').style.borderWidth = "2px"

  document.getElementById('error-hora').innerText = "Horário é obrigatório"
}

if(local === "") {
  document.getElementById('local').style.borderColor = "red"
  document.getElementById('local').style.borderWidth = "2px"

  document.getElementById('error-local').innerText = "Por favor, digite o nome do abrigo que irá visitar"
}

const pet = {
  foto: foto,
  nome: nome,
  idade: idade,
  cor: cor,
  categoria: categoria,
  descricao: descricao,
  responsavel: responsavel,
  email: email,
  telefone: telefone,
  data: data,
  hora: hora,
  local: local
}

let listaNoLocalStorage = JSON.parse(localStorage.getItem("pets"))    // vai no local storage e pega a lista
  
if(listaNoLocalStorage === null) listaNoLocalStorage = [] 

listaNoLocalStorage.push(pet) 
 
localStorage.setItem("pets", JSON.stringify(listaNoLocalStorage)) // salvar no local storage

}

document
  .getElementById("form-pet")
  .addEventListener("submit",cadastrarPet);
